import { GamePage } from './GamePage';

export { GamePage };
