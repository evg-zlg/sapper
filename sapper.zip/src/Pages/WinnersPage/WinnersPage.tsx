function WinnersPage() {
  return <h1>Winners page</h1>
}

export { WinnersPage };