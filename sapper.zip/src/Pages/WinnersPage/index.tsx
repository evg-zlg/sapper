import { WinnersPage } from './WinnersPage';

export { WinnersPage };
