import RootRouter from './RootRouter';

export default RootRouter;