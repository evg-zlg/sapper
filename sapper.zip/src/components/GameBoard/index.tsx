import { GameBoard } from './GameBoard';

export { GameBoard };
